# CFPilot

> Cloudflare 代理微内核 · 真连接优选面板 · 盲中继与云监测台 · 异地组网（+mesh）
> AGPL-3.0 License · 控制面+数据面完全自研（无第三方内核依赖）

· 把「代理内核 + 优选订阅 + 本地真连接优选 + 盲中继 / 云监测台 + 异地组网（+mesh）」整合成一套方案；

· 采用双项目拆分部署：控制面（Web 管理面板）跑 Pages，数据面（流量转发）可选 **Pages（默认）** 或 **Workers**；

· 静态脱敏 + 内核独立热更新通道（`kernel-latest`），转发内核始终保持正式版升级形态；

· 解决优选 IP 困扰：**本地真连接优选避免导入后延迟 `-1`**；反代入口池内置双通自愈机制与动态保活清单，开箱即用。

***

## 目录

- [部署](#部署)

- [盲中继 / 云监测台与异地组网（+mesh）](#盲中继--云监测台与异地组网mesh)

- [优选 IP](#优选-ip)

- [导入订阅](#导入订阅)

- [使用须知](#使用须知)

- [常见问题](#常见问题)

- [技术实现](#技术实现)

- [配置项与环境变量](#配置项与环境变量)

- [免责声明](#免责声明)

***

## 部署

> ⚠️ **部署前必读**

> 全自动化：填 Token  → 自动部署  → 自动优选换 IP → 自动更新内核 → 日常维护 。
>
> 1. 全自动化使用需获取 Cloudflare Api Token 至少**三个权限**（数据面选 Workers 时是**六个**，见下文权限表）。
> 2. **控制面 + 数据面必须分开**（控制面固定 Pages；数据面可选 Pages 或 Workers）。
>    选 Workers 时**必须**配一个自有域名，`*.workers.dev` 直连不可访问。
> 3. **不要与其它项目共用 KV** 。
> 4. 免 Api Token 部署请**选择手动部署**流程。

<details>
<summary><b>① 远程部署（npx，无需安装）</b></summary>

<br>

```bash
npx -y cfpilot@latest deploy
```

交互式引导会依次完成：检测账号 → 创建/复用 KV → 部署数据面 → 部署控制面 →
绑定变量 → 打印面板地址与密码。

**注意事项**

- 全程约 1-3 分钟，取决于 Cloudflare API 响应

- 部署完成后**立即保存面板密码** —— 云端环境变量是加密的，之后无法再读

- 手动部署没设 `PANEL_PASSWORD` 时，内核会随机生成一个密码并写入 KV 的
  `ADMIN_PW_PLAIN` 供你取回；它只保留到**第一次登录成功**为止（之后自动删除）

- 同一账号部署第二个实例：加 `--new-kv`(不建议同账号多实例)

</details>

<details>
<summary><b>② CLI 安装部署（npm 全局安装）</b></summary>

<br>

```bash
npm i -g cfpilot
cfpilot
```

进入中文交互菜单：

```
┌──────────────────────────────────────────────────┐
│ cfpilot                                          │
├──────────────────────────────────────────────────┤
│ Cloudflare Pages 代理部署与优选                  │
└──────────────────────────────────────────────────┘

  当前状态
  账号  未配置
  实例  未配置
  凭据  未配置

  ❯ 部署新实例
    更新现有实例
    查看实例状态
    本地优选（真连接测速）
    修改面板密码
    检查 Token 权限
    配置（Token / 账号 / KV）
    帮助
    退出
```

也支持子命令（供脚本自动化）：

```bash
cfpilot deploy      # 部署
cfpilot scan        # 本地优选
cfpilot status      # 查看实例
cfpilot token --check  # 检查 Token 权限
cfpilot config      # 配置管理
```

**注意事项**

- 首次进入「配置」菜单填 Token，会自动识别账号与已有实例

- 配置保存在 `~/.cfpilot/config.json`，Token 显示时脱敏

- 该文件权限为 `0600`、目录 `0700`（一旦选择保存 Token，它等同于账号凭据）

- `cfpilot deploy --token <TOKEN>` 会把 Token 留在 Shell 历史里；
  更安全的方式是进入交互菜单填写，或设环境变量 `CF_API_TOKEN`

- 需要 Node.js 18+

</details>

<details>
<summary><b>③ 桌面版（Go 图形界面，推荐）</b></summary>

<br>

到 [Releases](https://github.com/xmwengxing/CFPilot/releases) 下载对应平台文件：

| 平台 | 普通版（代理部署 / 优选 / 盲中继与云监测台） | +mesh 组网版（额外包含异地组网节点） |
| --- | --- | --- |
| Windows x64 | `cfpilot-<版本>-windows-amd64.exe`（绿色单文件） | `cfpilot-<版本>+mesh-windows-amd64-setup.exe`（安装向导） |
| Linux x64 | `cfpilot-<版本>-linux-amd64` | `cfpilot-<版本>+mesh-linux-amd64.deb` |
| Linux arm64 | `cfpilot-<版本>-linux-arm64` | `cfpilot-<版本>+mesh-linux-arm64.deb` |
| Android | `cfpilot-<版本>-android.apk`（完整管理面板） | `cfpilot-<版本>+mesh-android.apk`（独立组网客户端） |

运行后托盘出现图标，并直接打开 CFPilot 面板窗口；关掉窗口后服务继续在托盘里运行。

Linux 普通版下载后要先 `chmod +x`，操作流程见下面的 [Linux 版](#linux-版)。
Linux 的面板窗口用系统 WebKitGTK；没装 WebKitGTK 或没有图形会话时，
会自动回退成系统浏览器打开同一个面板（功能一致）。
`--browser` 可强制使用系统浏览器。

<img src="docs/images/go-credentials.png" alt="CFPilot Go 版凭据页：自动检测账号并自动选中唯一的 CFPilot 实例" width="720">

界面包含 **凭据 / 部署 / 优选 / 数据源 / 说明 / 日志** 页签（+mesh 版额外显示 **组网** 页签），下方是常驻运行日志（可折叠）。

- **凭据页**：填 Token → 自动检测账号 → 自动列出 KV；账号下只有 **1 个** CFPilot 实例时
  自动选中并保存（如上图），**0 个 / 多个**会用醒目红框提示（选错 KV 会让后续操作作用到别的实例上）

- **部署页**：全新部署会自动新建一个独立 KV（一 KV 一实例，不复用凭据页选中的那个）

- **优选页**：「自动识别」一次填好域名与 WS 路径 → 开始优选 → 回填面板

- **说明页**：安全说明、Token 权限清单、应用更新

**注意事项**

- 单文件静态可执行，**零依赖**，不需要预装 Node.js

- 启动后**自动打开**管理界面（`--no-browser` 可关）

- 服务只监听 `127.0.0.1`，凭据存在本机 `~/.cfpilot-gui/secrets.json`
  （文件 `0600`、目录 `0700`；Windows 下由用户目录的 ACL 保护）

- 「允许局域网访问」默认关闭。开启后仅额外放行私有网段，
  且仍需一次性启动令牌 → Session Cookie 才能操作，不是只靠 Origin 校验

- 应用内更新会先取官方 Release 的 `cfpilot-desktop-SHA256SUMS`，
  校验安装包摘要后再提示替换；清单缺失或摘要不符一律拒绝（镜像不参与校验）

- 右键托盘可查看服务状态、复制地址、修改端口、启停服务、快捷一键优选 IP

- 常用参数：`--no-browser`（不自动开浏览器）、`--no-tray`（无桌面环境）、
  `--console`（日志同时打终端）、`--check`（只自检）

### Linux 版

Linux 版**不是另一套代码**：与 Windows 共用同一份 Go 源码和同一份界面（界面构建后 `go:embed` 进二进制），
仅三处按平台分支——打开浏览器（`xdg-open`）、桌面通知（`notify-send`，未安装时只写日志）、
托盘（D-Bus StatusNotifierItem，纯 Go 实现）。因此**不需要 GTK / libappindicator，也不需要 Node.js**，
`CGO_ENABLED=0` 静态编译，x64 与 arm64 各一份单文件产物。

放置路径随意（程序不依赖当前工作目录，内嵌内核也不会去读旁边目录），但**必须加执行位、建议从终端启动**：

```bash
# 1. 放到固定位置（示例：家目录下的 Applications）
mkdir -p ~/Applications
mv ~/Downloads/cfpilot-<版本>-linux-amd64 ~/Applications/cfpilot

# 2. 浏览器下载的文件默认没有执行位
chmod +x ~/Applications/cfpilot

# 3. 从终端启动（首次运行别双击，见下方说明）
~/Applications/cfpilot
```

启动后托盘出现图标，浏览器自动打开 `http://127.0.0.1:19726/?t=<一次性令牌>`。
`t` 只在本次启动有效，重启会换新的；退出用托盘菜单「退出 CFPilot」。

> 许多文件管理器会双击二进制时把它当文本打开、或直接拒绝执行（取决于桌面设置），
> 所以首次运行请用终端；启动日志也会直接打在终端里，便于确认端口与地址。

**托盘需要一个 StatusNotifierItem 宿主**：KDE / XFCE / Cinnamon / MATE 原生支持；
GNOME 默认不支持（Ubuntu 自带的 AppIndicator 扩展默认启用，所以 Ubuntu 一般可见）。
如果启动后**没有图标**，说明当前桌面没有宿主，改用前台模式即可——服务与界面完全一致，只是没有托盘菜单：

```bash
~/Applications/cfpilot --no-tray                            # 前台跑服务，Ctrl+C 退出
~/Applications/cfpilot --no-tray --no-browser --console      # SSH / 纯命令行：不弹浏览器，日志同时打终端
~/Applications/cfpilot --check                              # 只自检：配置目录 / 端口占用 / 版本
```

| 项目    | Linux 下的位置与行为                                                          |
| ----- | ---------------------------------------------------------------------- |
| 配置与凭据 | `~/.cfpilot-gui/`（`secrets.json` 权限 `0600`、目录 `0700`），格式与 Windows 完全相同 |
| 日志    | `~/.cfpilot-gui/cfpilot.log`（自动滚动）；加 `--console` 时同步打终端                |
| 应用内更新 | 只**下载**到 `~/.cfpilot-gui/updates/`；替换需手动：退出程序 → `chmod +x` 新文件 → 覆盖旧文件 |
| 卸载    | 删除二进制 + `~/.cfpilot-gui/` 目录即可，不写注册表 / 系统目录                            |

### Docker 版

容器版跑的是**同一份 Go 源码和同一份界面**，与桌面二进制没有区别 —— 区别只在外壳：
没有托盘、没有桌面通知、不自动开浏览器（容器里也没有这些东西）。

适合的场景：NAS、软路由、小主机、长期挂着跑定时优选任务。
桌面用户用上面的二进制更合适。

#### ① 直接拉镜像运行（推荐）

镜像在 GitHub Container Registry 上，**公开可拉、无需登录**，
**一个镜像同时含 amd64 与 arm64**，Docker 会自动挑当前机器的架构。

```bash
# 1. 拉镜像
docker pull ghcr.io/xmwengxing/cfpilot:latest

# 2. 运行
docker run -d --name cfpilot \
  -p 127.0.0.1:19726:19726 \
  -v cfpilot-data:/data \
  -e TZ=Asia/Shanghai \
  ghcr.io/xmwengxing/cfpilot:latest

# 3. 打开面板：地址在启动日志里（令牌每次启动随机，重启后要从日志里重新拿）
docker logs cfpilot | grep 管理界面
```

要固定版本就把 `latest` 换成版本号（如 `0.30.2`）—— 每次发布都有对应标签。

**升级**：重新拉镜像 + 重建容器

```bash
docker pull ghcr.io/xmwengxing/cfpilot:latest
docker rm -f cfpilot
docker run -d --name cfpilot \
  -p 127.0.0.1:19726:19726 \
  -v cfpilot-data:/data \
  -e TZ=Asia/Shanghai \
  ghcr.io/xmwengxing/cfpilot:latest
```

⚠️ 删容器**不影响数据** —— 配置、Cloudflare Token、优选历史都在 `cfpilot-data` 卷里。
⚠️ 但**启动令牌每次重启都会变**，旧地址里的 `?t=` 失效了，要从新的 `docker logs` 里重新取。

#### ② 自己构建

不想用现成镜像（比如要改代码）时，从源码构建：

```bash
# 1. 先编出 Linux 产物（镜像不在里面编译，Dockerfile 只做一次 COPY）
node scripts/build-desktop.mjs --only linux

# 2. 构建镜像（构建上下文是 docker/ 目录，很小）
docker build -f docker/Dockerfile -t cfpilot:local docker

# 3. 运行
docker run -d --name cfpilot \
  -p 127.0.0.1:19726:19726 \
  -v cfpilot-data:/data \
  -e TZ=Asia/Shanghai \
  cfpilot:local

# 4. 打开面板：地址在启动日志里（令牌每次启动随机，重启后要从日志里重新拿）
docker logs cfpilot | grep 管理界面
```

也可以直接用 compose：

```bash
docker compose -f docker/docker-compose.yml up -d
```

**启动后先看日志拿地址**：

```bash
docker logs -f cfpilot
# [cfpilot] 管理界面：http://127.0.0.1:19726/?t=<一次性令牌>
```

`?t=` 里的令牌用于**一次性换取会话 Cookie**（换完就不再需要）。
固定它可以加 `-e CFPILOT_BOOT_TOKEN=<你自己的随机串>` —— 但它**不是密码**，
拿到它的人换到 Cookie 后长期有效，别把它当访问控制用。

#### ⚠️ 暴露风险

面板持有 **Cloudflare Token 的读写权限**，能部署与删除 Cloudflare 项目、读写 KV、
查看全部优选池与订阅密钥。**谁能访问它，谁就能用你的 Cloudflare 账号。**

| 端口映射 | 谁能访问 |
| --- | --- |
| `-p 127.0.0.1:19726:19726` | 只有这台机器 ✅ **推荐** |
| `-p 19726:19726` | 整个局域网 ⚠️ |

局域网访问还要**额外**设 `CFPILOT_ALLOW_LAN=1`（否则浏览器会因为 Host 头是局域网 IP
被判「非法 Host」而拒绝）。启动日志里会打出风险警告。

⚠️ Host 校验**不是访问控制** —— 非浏览器客户端可以伪造 Host 头绕过它。
**真正的边界是宿主机上的端口映射。** 只在可信网络里开放，永远不要直接暴露到公网。

#### 容器里的环境变量

| 变量 | 默认 | 作用 |
| --- | --- | --- |
| `CFPILOT_DATA_DIR` | `/data` | 配置、凭据、内核缓存的存放目录（挂卷到这里） |
| `CFPILOT_PORT` | `19726` | 监听端口 |
| `CFPILOT_LISTEN_ADDR` | `0.0.0.0` | 监听地址。容器里**必须**是 `0.0.0.0`：Docker 的端口转发连的是容器网卡地址，只监听回环会「连得上但没响应」 |
| `CFPILOT_ALLOW_LAN` | `0` | 设为 `1` 允许局域网访问（放宽 Host 校验 + 打风险警告） |
| `CFPILOT_BOOT_TOKEN` | 随机 | 固定启动令牌 |
| `TZ` | — | 时区，定时任务的「运行时刻」按它解析 |

#### 容器里的差异

- **日志**：`docker logs` 看得到（等价于 `--console`）；同时也在 `/data/cfpilot.log`。
- **更新**：镜像不会自动更新，重新拉镜像 + 重建容器即可。
  程序内「检查更新」只下载内核资产，不替换容器里的程序。
- **数据**：一定要挂卷（`-v cfpilot-data:/data`），否则容器一删，Cloudflare Token 就要重填。
- **定时优选任务**：容器常驻，比在手机上跑更合适 —— 这是容器形态的主要价值。

#### 排障

**容器里解析不了域名**（`wget: bad address 'api.cloudflare.com'`）

Docker 的内嵌 DNS（默认 `192.168.65.7`）没把查询转发出去。两种解法，任选其一：

```bash
# A. 给这个容器指定 DNS（最快）
docker run --dns 223.5.5.5 --dns 1.1.1.1 ...

# B. 给 Docker 引擎全局指定（所有容器都受益）
#    Docker Desktop → Settings → Docker Engine → 加上：
#    { "dns": ["223.5.5.5", "1.1.1.1"] }
```

**`docker pull` 拉不动镜像**（`Docker Desktop has no HTTPS proxy`）

Docker Desktop 自己的出网也要走代理：Settings → Resources → Proxies → Manual proxy
→ **HTTP 和 HTTPS 都要填**。地址用宿主机的局域网 IP（如 `192.168.31.19:10808`）——
daemon 跑在 WSL2 虚拟机里，`127.0.0.1` 指的是虚拟机自己，不是宿主机。

### 托盘菜单

| 菜单项        | 作用                         |
| ---------- | -------------------------- |
| 打开业务界面     | 打开管理界面                     |
| 复制服务地址     | 复制当前地址                     |
| 停止服务       | 启停本地服务                     |
| 切换端口       | 预设端口，一键切换                  |
| 允许局域网访问    | 同网段其它设备可访问                 |
| **检查应用更新** | 检查 exe 有无新版（外壳 / 界面 / 优选器） |
| **检查部署更新** | 检查线上内核有无新版（数据面 / 控制面）      |
| 一键优选 IP    | 后台自动完成优选 IP 并回填面板，更新订阅食用   |
| 退出 CFPilot | 停止服务并退出                    |

</details>

<details>
<summary><b>④ 手动部署（Cloudflare 控制台）</b></summary>

<br>备用方案，用仓库根目录的两份压缩包手动上传。

| 文件                                               | 用途                         |
| ------------------------------------------------ | -------------------------- |
| [`CFPilot-dataplane.zip`](CFPilot-dataplane.zip) | 数据面（纯转发，Pages 方式上传）        |
| [`CFPilot-control.zip`](CFPilot-control.zip)     | 控制面（面板与订阅，Pages 方式上传）      |
| [`_worker.js`](_worker.js)                       | 数据面**代码文件**（Workers 方式粘贴用） |

> 三份文件随每次构建自动更新，与本仓库代码一致。

**第 1 步：创建 KV**

Cloudflare 控制台 → **存储和数据库 → KV** → 创建命名空间，记下**命名空间 ID**。

**第 2 步：部署数据面（两种形态二选一）**

控制面**始终**是 Pages 项目；数据面可以选 Pages 或 Workers。
两种形态都可以，区别只有一条：**Workers 必须配自定义域名**。

<details>
<summary><b>2A. Pages 方式（默认，不需要自有域名）</b></summary>

1. **Workers 和 Pages → 创建 → Pages → 上传资产**

2. 项目名随意（建议普通名称，如 `blog-assets-sync`）

3. 上传 `CFPilot-dataplane.zip`，记下项目域名（形如 `xxx.pages.dev`）

4. **设置 → 变量和密钥**，添加：

   | 名称              | 值                  |
   | --------------- | ------------------ |
   | `UUID`          | 自己的 UUID（36 位标准格式） |
   | `WS_PATH`       | 自定义路径，如 `/abc123`  |
   | `ENABLE_TROJAN` | `true` / `false`   |
   | `ENABLE_XHTTP`  | `true` / `false`   |

5. **设置 → 函数 → KV 命名空间绑定**：变量名 `KV` → 第 1 步的命名空间

6. **重新上传一次压缩包**（绑定与变量只对之后的部署生效）

</details>

<details>
<summary><b>2B. Workers 方式（需要自有域名，动态与边缘控制更强）</b></summary>

> ⚠️ `*.workers.dev` 域名直连无法访问，**必须**在最后一步绑一个自定义域名，
> 否则客户端节点全部连不上。该域名要托管在**本 Cloudflare 账号**里
> （Workers 自定义域名不支持外部 CNAME）。

1. **Workers 和 Pages → 创建 → Workers → 从 Hello World 开始**

2. 脚本名随意（建议普通名称），点「部署」

3. 进入 **编辑代码**，删掉默认示例，把仓库根目录 [`_worker.js`](_worker.js)
   的**全部内容**粘贴进去 → 右上角「部署」

   > 代码是单文件 ES module，不需要 `wrangler.toml`，也不需要构建步骤。

4. **设置 → 变量和密钥 → 添加**（与 2A 的表完全一致）：

   | 名称              | 值                  |
   | --------------- | ------------------ |
   | `UUID`          | 自己的 UUID（36 位标准格式） |
   | `WS_PATH`       | 自定义路径，如 `/abc123`  |
   | `ENABLE_TROJAN` | `true` / `false`   |
   | `ENABLE_XHTTP`  | `true` / `false`   |

5. **设置 → 绑定 → 添加 → KV 命名空间**：变量名 `KV` → 第 1 步的命名空间

   > 变量与绑定保存后会自动创建一个新版本并部署；若页面上没有自动生效，
   > 回「部署」页点一次部署即可。

6. **设置 → 域和路由 → 添加 → 自定义域名**：填 `w1.example.com` 这类子域，
   等状态变成 **Active**（证书签发通常 1\~3 分钟）

7. 记下这个**自定义域名** —— 第 3 步的 `DATA_HOST` 用它（不是 `*.workers.dev`）

> 想换回 Pages 形态？删掉这个 Worker，按 2A 重做一遍即可 ——
> 用 CLI / 桌面版更新部署时会**自动**完成这套清理与域名迁移。

</details>

**第 3 步：部署控制面**

1. 另建一个 Pages 项目，上传 `CFPilot-control.zip`

2. **设置 → 变量和密钥**：

   | 名称               | 值                                                         |
   | ---------------- | --------------------------------------------------------- |
   | `UUID`           | 与数据面相同                                                    |
   | `WS_PATH`        | 与数据面相同                                                    |
   | `DATA_HOST`      | 第 2 步记下的**数据面域名**（Pages 的 `*.pages.dev` 或 Workers 的自定义域名） |
   | `PANEL_PATH`     | 面板路径，如 `/mypanel`                                         |
   | `PANEL_PASSWORD` | 面板登录密码                                                    |

   > ⚠️ **变量名是 `PANEL_PASSWORD`，不是 `ADMIN_PASSWORD`。** 写成后者内核读不到，
   > 会随机生成一个密码写进 KV 的 `ADMIN_PW_PLAIN`，表现就是「一直用自带的密码」。
   > 保存变量后必须做第 4 步**重新部署一次**（Pages 的变量只对之后的部署生效）；
   > 重新部署后内核会按 `PANEL_PASSWORD` 刷新密码并自动清掉旧的明文，不用手动清 KV。

3. **设置 → 函数 → KV 命名空间绑定**：`KV` → 同一个命名空间

4. **重新上传一次压缩包**

**第 4 步：访问**

打开 `https://<控制面域名><PANEL_PATH>`，用 `PANEL_PASSWORD` 的值登录。
订阅地址：`https://<控制面域名>/sub/<UUID>`

**更新时**：

- 数据面是 Pages：打开项目 → 新建部署 → 上传新版 `CFPilot-dataplane.zip`

- 数据面是 Workers：打开脚本 → 编辑代码 → 用新版 `_worker.js` 覆盖 → 部署

- 控制面：打开项目 → 新建部署 → 上传新版 `CFPilot-control.zip`

</details>

***

## 盲中继 / 云监测台与异地组网（+mesh）

CFPilot 在原有代理部署与优选能力之外，提供**盲中继 / 云监测台**部署能力，以及 **`+mesh` 异地组网**模块，用于把分散在不同网络（家宽 / 办公室 / 云主机 / 手机）的设备安全连入同一张虚拟局域网。

### 模块简介

- **盲中继（Cloudflare Workers + Durable Objects）**：基于零知识房间转发端到端加密数据包（Noise IKpsk2 + ChaCha20-Poly1305），中继节点本身不持有私钥、无法解密业务流量，用于在双端对称 NAT 无法直连时自动降级兜底；
- **云监测台（Cloudflare Workers + D1）**：免费托管的只读设备状态面板，展示各组网节点的在线状态、心跳时间与延迟概览；
- **异地组网（+mesh）**：
  - 优先 **UDP P2P 直连**（STUN 探测 + 协同打洞），不通时自动平滑降级到 **盲中继（WSS）** 或自建 **服务器中继**，网络恢复后自动回切直连；
  - 支持 **邀请链接一键入网**：一端生成邀请链接，其余设备粘贴即可自动填入网络名、PSK、盲中继与监测台参数；
  - 桌面端界面提供实时网络拓扑与状态视图，支持「组网入口」WSS 优选；
  - Android `+mesh` 版为独立组网客户端（基于 `VpnService`），打开即可粘贴邀请链接一键入网。

### 快速开始

1. **部署盲中继与云监测台**（普通版 / +mesh 版均支持）：
   - 打开 CFPilot 桌面版「部署 → 盲中继 / 云监测台」页签（或运行 `cfpilot edge deploy`）；
   - 选择已托管在 Cloudflare 账号下的域名与子域、设置监测台密码，点击一键部署；
   - 部署完成后点击「填入组网配置」自动带入中继域名与监测台信息。
2. **启动第一个组网节点**（需安装 `+mesh` 版）：
   - Windows 运行 `cfpilot-<版本>+mesh-windows-amd64-setup.exe` 安装（安装器会自动注册提权组网服务并下载校验 `wintun.dll`）；
   - Linux 安装对应架构的 `.deb` 包（`sudo dpkg -i cfpilot-<版本>+mesh-linux-<arch>.deb`）；
   - 在「组网」页填写网络名称、预共享密钥（PSK）、虚拟 IP（同网络所有设备使用同一网段不同地址，如 `10.99.0.1/24`）及盲中继域名，点击启动。
3. **加入其它设备**：
   - 在已配置好的节点上复制「邀请链接」；
   - 在另一台电脑（`+mesh` 桌面版）或手机（`cfpilot-<版本>+mesh-android.apk`）粘贴邀请链接，修改本机虚拟 IP（如 `10.99.0.2/24`）后点击启动，即可互通并自动发现对端。

> 如需在自有 VPS 部署专用 UDP 服务器中继，可在「组网 → 高级选项」中一键生成部署命令并回填输出参数。

***

## 优选 IP

部署完成后，建议跑一次本地真连接优选，把「看起来快但实际不可用」的 IP 剔掉。

```bash
# 已安装 CLI
cfpilot scan

# 或直接用 npx
npx -y cfpilot@latest scan
```

交互式引导会：识别实例 → 自动填域名与 WS 路径 → 扫描 → 询问是否回填面板。

**通用流程**

1. **关掉所有代理工具**（含 TUN 模式与系统代理）
2. 选择实例（或手动填数据面域名 + WS 路径）
3. 设置采样数与是否跳过测速后开始优选（建议默认）
4. 扫描完成后选 `y` 自动回填，或选 `N` 复制结果手动粘贴
5. 回填后面板「节点来源 → 手动优选 IP」即可看到列表

- 桌面版根据图形界面提示说明操作，易用性更强。

***

## 导入订阅

面板首页给出三种订阅地址，**按 User-Agent 自动识别格式**：

| 客户端                             | 拿到的格式       |
| ------------------------------- | ----------- |
| Clash Verge / Clash / mihomo    | YAML        |
| sing-box                        | JSON        |
| v2rayN / Shadowrocket / NekoBox | Base64 分享链接 |

也可显式指定：`?target=clash` / `?target=singbox` / `?target=base64`。

节点的关键约定：`server` = 优选出的 **IP**，`sni` / `Host` = **你的域名**（固定），端口 = `443`。

***

## 使用须知

### API Token 权限

在 [Cloudflare 控制台 → API Tokens](https://dash.cloudflare.com/profile/api-tokens)
创建**自定义 Token**，按下面三项勾选（分类都是 **Account**，权限级别都是 **Read/**Edit）：

| 权限项（控制台显示名）             | 级别   | 分类                 | 用途                                   |
| ----------------------- | ---- | ------------------ | :----------------------------------- |
| **Account Settings**    | Read |                    | 读取账号列表（`GET /accounts`）              |
| **Workers KV Storage**  | Edit | Developer Platform | 建 KV、读写部署清单与 `CONFIG`                |
| **Pages**               | Edit | Developer Platform | 建/删 Pages 项目、上传内核、绑 KV、配环境变量、绑自定义域名  |
| **Account API Tokens**  | Read | Account & Billing  | 可选，仅用于显示 Token 有效期                   |
| **Account Analytics**   | Read | Analytics & Logs   | 可选，仅用于「用量/额度」面板（查 Workers 与 KV 的已用量） |

**数据面用 Workers 模式时，再加一项**：

| 权限项（控制台显示名） | 级别    | 分类                 | 用途                   |
| ----------- | ----- | ------------------ | -------------------- |
| **Workers** | Admin | Developer Platform | 上传 / 更新数据面 Worker 脚本 |

> ✅ **不需要** `Workers Routes`，也**不需要** `DNS` —— 工具不碰自定义域名：
> Workers 模式只把数据面部署到 `*.workers.dev`，自定义域名请你在控制台自行绑定，
> 然后到面板「设置 → 数据面域名」填一次（`CONFIG.subDomain` 优先级高于 `DATA_HOST`）。
>
> ⚠️ **Workers 模式 + 自定义域名时，`workers.dev`** **的生产链接与预览链接会被工具关掉**，
> 节点只走自定义域名（`*.workers.dev` 在多数网络下直连不可访问）。
> 部署时若填的域名与数据面**已绑定的**域名不一致、或是控制面 / 账号里别的 Worker 的域名，
> 工具会**直接拒绝部署**并说明原因 —— 避免把错域名写进 `DATA_HOST` 导致节点不可用。





<details>
<summary><b>📋 点开看「照着勾」的图解</b>（哪些必勾 / 哪些不用勾 / 操作步骤）</summary>

<img src="docs/images/cfpilot-token-permissions.png" alt="Cloudflare API Token 权限勾选指引" width="880">

</details>

### 数据面出站能力边界

| 目标类型                            | 能否打通                                   |
| ------------------------------- | -------------------------------------- |
| 普通站点（baidu / qq / amazon 等）     | ✅ 直连                                   |
| Cloudflare 网段目标                 | ✅ 内置第三方反代入口（面板可自配）                     |
| Google / YouTube / GitHub 等 443 | ✅ 内置假活检测会自动切反代；若不通建议配 SOCKS5/HTTP 代理落地 |

***

## 订阅接入

节点形态在面板「入站配置」里选，默认下发 **VLESS + WebSocket** 与 **VLESS + XHTTP** 两种形态。

| 形态                        | 支持        |
| ------------------------- | --------- |
| VLESS + WS                | 全部客户端     |
| Trojan + WS               | 全部客户端     |
| VLESS + XHTTP（packet-up） | Xray 内核、新版 mihomo（1.19+）；实测稳定 |

> mihomo / Clash.Meta 自 1.19+ 已支持 XHTTP 节点；老版本会忽略该节点，不影响 WS 节点。
> sing-box 暂不支持，订阅里不下发。

### ECH（Encrypted Client Hello）

ECH 把 TLS ClientHello 里的真实 SNI 加密，隐藏你访问的是哪个域名。
**这是客户端侧的能力** —— 内核只负责把参数写进订阅，由支持 ECH 的客户端
（mihomo / Clash Verge、sing-box 1.13+、v2rayN）实际执行；客户端不支持时参数被忽略，不影响连接。

**默认关闭**，在面板「出站与抗封锁」页勾选「启用 ECH 加密」后保存即可。
没有自定义域名时客户端连的是 `*.pages.dev`，ECH 的实际收益有限。

***

## 常见问题

**Q：优选结果全是** **`-1`？**
按顺序查：① 是否绑了自定义域名；② 客户端 `sni` 与 `Host` 是否都指向你的域名；
③ 优选时 `--host` 是否和实际部署一致；④ 端口是否是 443 等 TLS 端口；
⑤ 跑优选时是否关了代理工具。

**Q：配了 SOCKS5 代理但不生效？**
检查这几项：① 代理地址是否可公网访问（`127.0.0.1` / `192.168.x` 这类地址数据面连不到）；
② 代理是否支持 TLS 1.3（HTTPS 代理需要）；③ 代理服务器是否有 **IPv4** 公网地址
（数据面的出站只支持 IPv4）。

**Q：Linux 版双击没反应 / 没有托盘图标？**
浏览器下载的文件默认没有执行位，先 `chmod +x`，再从终端启动（双击常被文件管理器当成文本打开）。
没有图标说明当前桌面缺 StatusNotifierItem 宿主（GNOME 默认如此），改用 `--no-tray` 前台运行即可，
服务与界面一致，只是少了托盘菜单；纯命令行 / SSH 环境也用它。

**Q：面板打不开 / 404？**
面板路径是部署时随机生成的，向导终端里打印过。忘了可以用
`npx wrangler kv key get --binding KV PANEL_PATH` 查回。

**Q：XHTTP 节点连不上？**
需要 Xray 内核或新版 mihomo（1.19+，`network: xhttp`）；sing-box 请改用 WS 节点。
老版本 mihomo 会直接忽略 XHTTP 节点（不是报错），不影响其它节点。
默认下发的 XHTTP 节点使用 `packet-up` 模式并关闭 gRPC 伪装头；若个别网络环境下仍受限，可切回 WS 节点使用。

**Q：免费额度 CPU 超限？**
内核内置 Free CPU 预算保护，可在面板调低 `DLS` / `MAX_LATENCY` 阈值，或减少远程 CSV 行数。

**Q：想看「为什么这个目标连不上」？**
自研数据面提供完整诊断端点，需要带上**完整 UUID**（面板「节点配置」里可见）：

```bash
curl \
  -H "x-cfpilot-token: <完整 UUID>" \
  https://<数据面域名>/__diag
```

返回最近 20 条完整出站诊断（失败类型 / 原始错误 / 候选 / 修复建议）——
WebSocket close frame 装不下这些（且超长会被边缘静默丢弃），所以单独开了个口子。

> ⚠️ 只认**完整 UUID**：早期允许 UUID 前 8 位，但那是 32 bit 搜空间，
> 可被在线枚举（诊断里有你访问过的目标域名）。失败尝试也有限速（每 isolate 每分钟 10 次）。

**Q：`/__edge_probe`** **会不会被别人刷流量？**
该端点必须保持免鉴权（它是优选的核心：WS 101 校验 + 流式测速），所以内置两道闸：
单次最多 8 MiB，以及**每个 isolate 每 10 分钟约 6 GiB** 的总预算，超出返回 429。
正常一轮优选（约 50 条候选 × 8 连接 × 5 MiB）大约 2 GiB，跑不满。
如果你担心被滥用，可在 Cloudflare 控制台给该路径加一条 Rate Limiting 规则。

***

## 技术实现

<details>
<summary><b>▸ 展开：内核与优选器的技术方法总览</b>（三张表：边缘内核 / 优选器 / 工程与发布）</summary>

### 一、边缘内核

部署形态：**Pages 控制面 + Pages / Workers 数据面**，单份源码两套构建产物。

| 能力        | 技术方法                                                                                                                  |
| --------- | --------------------------------------------------------------------------------------------------------------------- |
| 入站协议      | VLESS over WS、Trojan over WS（SHA-224 口令散列）、VLESS over XHTTP（packet-up / stream-one）；协议响应头在出站建连**之前**立即回写，避免长握手被判定挂起 |
| 出站选路      | 代理候选与直连候选**互斥**竞速（用户配了代理就不许偷偷直连）；Cloudflare 网段自动降权（回连自身 Anycast 入口会被判 TCP Loop）                                       |
| 出站传输      | 直连、SOCKS5、HTTP 代理、HTTPS 代理（TLS 1.3 + 自定义 SNI）、NAT64、ProxyIP、反代入口池                                                     |
| 反代入口      | 双通精选内置表 + 动态保活清单（isolate 内存缓存、零 KV 写入）+ 用户自配；按域名记忆有效出口并支持 TLS 致命告警/假活熔断自愈                                        |
| 假活处理      | 建连成功但下行无有效数据或首包返回 TLS 致命告警 → 判定异常并自动熔断换入口重拨                                                                             |
| 连接预算      | 单请求最多 6 条并发出站；窗口化分批（分批不等于截断候选，坏批次才放下一批）                                                                               |
| 握手细节      | WebSocket close reason 按 **123 字节**截断（超长会被边缘静默丢弃，表现为连接永不关闭）                                                           |
| 完整诊断      | `GET /__diag` 返回最近 20 条完整多行原因（含目标域名与失败分级），不受 close reason 长度限制                                                        |
| 探针端点      | `/__edge_probe`：WS 101 握手 + 流式下行测速；单次 ≤ 8 MiB，每 isolate 每 10 分钟 6 GiB 总量上限                                            |
| 订阅引擎      | 四层优选池（官方优选 / 域名库 / 手动列表 / 本地回填）+ 远程池（API / CSV，120 秒 per-isolate 缓存）；多格式输出（vless / trojan / clash / singbox / base64） |
| 域名库       | 用户自定义域名与内置随机域名**互补**下发，按主机名去重合并                                                                                       |
| 配置体系      | `KV(CONFIG) > 环境变量 > 内置默认值`；KV 键全局平铺（一个命名空间 = 一个实例）；写入配额保护（先读后比、删前先读，避免把每天 1000 次配额写光）                                |
| 面板        | 零框架单文件 HTML；静态脱敏（控制面字面量级 / 数据面全量级）；构建体积预算（数据面 ≤ 96 KB / 控制面 ≤ 108 KB），超限即失败 |
| 鉴权        | 版本化 PBKDF2 口令散列 + HttpOnly 会话 Cookie + 一次性扫描令牌；常量时间比较、按 IP 限速                                                         |
| 订阅鉴权      | 签名令牌（legacy / signed 双模式）+ 可选有效期                                                                                      |
| CPU 预算    | 面板接口按 Free 套餐的 CPU 预算做保护与降级                                                                                           |
| 出站伪装      | 客户端指纹（uTLS）可选、TLS 分片可选、ECH 可开关                                                                                        |
| UDP / DNS | UDP over WS 可用；DNS 出口可选 DoH（默认关闭）                                                                                     |
| 路由配置      | 面板内按「分组 → 规则 → 域名 / 国家」编排路由，生成对应客户端的规则段                                                                               |
| 配置备份      | 脱敏导出、导入前先出**差异预览**，确认后才写入                                                                                             |

### 二、优选器

CLI 与桌面版**同一套语义**，逐位对齐（见下方「工程与发布」的跨端一致性）。

| 能力             | 技术方法                                                                                                       |
| -------------- | ---------------------------------------------------------------------------------------------------------- |
| 阶段一 · TCP 初筛   | 自适应并发（上限 `min(8, 用户设置)`）+ 失败重试；候选按**网段实测可用率**加权采样（每段 12 样本实测得出权重表，权重 0 的段只进探索）                             |
| 阶段一之二 · TLS 筛选 | 用**你自己的域名**作 SNI 完成完整 TLS 握手，按握手耗时排序（这是导入客户端后大量 `-1` 的主要根因）                                                |
| 阶段二 · 真连接校验    | WebSocket 101 协议升级 **+ PING/PONG 响应体内容校验**，拦掉「握手能过但数据面不响应」的假活 IP                                           |
| 阶段三 · 真实测速     | 多连接（默认 8 条，上限 8）+ 丢弃前 1 秒预热 + 稳态吞吐排序；峰值仅作诊断（单窗口突发会虚高，不参与排序）。测速时长默认 6 秒、上限 10 秒；一轮约消耗 1GB 流量                |
| 测速目标           | 自有实例走 `/__edge_probe`；其它项目回落公开测速地址（仍先做 101 校验）                                                             |
| 结果去集中          | 按 /16 网段轮流取优，避免整批集中在同一网段（一段路由拥塞就全军覆没）                                                                      |
| 机房筛选           | 阶段二之后按 colo 过滤（colo 只在 101 响应里才有）；带筛选时自动扩大阶段二候选池，避免目标地区被截断                                                 |
| 采样随机性          | 默认随机种子（时间 ^ 随机）；只有显式 `--seed` 才可复现（写死种子会让每次跑出同一批候选）                                                        |
| 自适应网段权重（实验性）   | 按「运营商 · 地区 · 接入方式」分档学习：Beta 平滑（先验折算 8 个虚拟样本）+ 7 天半衰期 + 固定探索预算 + /24 集中度上限；档案只存本机、不同档案互不混用                  |
| 质量报告           | 每个 IP 的分阶段耗时、稳态/峰值速度、P95 与抖动、出口识别、网站兼容性、历史趋势；拿不到的字段显式标「暂未实现」，不用空值糊弄                                        |
| 出口识别（实验性）      | 指定传输路径（SOCKS5 / HTTP）经自有服务回显出口 IP 与机房                                                                      |
| 网站兼容性（实验性）     | 对用户指定站点做 403 / 挑战页 / 429 分类与内容校验                                                                           |
| 单 IP 诊断        | 逐阶段定位卡在哪一步                                                                                                 |
| 历史与复测          | 每次优选成功自动留底（保留最近 30 次），可二次复测可用性、跨天看趋势                                                                       |
| 效果对照           | 同档案、同域名的「开 / 关自适应」分阶段通过率对照（样本不足时明确标注，不硬给结论）                                                                |
| 代理干扰检测         | 优选前检测本机代理监听并提示关闭（流量被代理接管时所有 IP 成绩趋同，导入客户端后大量 `-1`）                                                         |
| 部署向导           | KV 归属五分支校验（空 / 自有 / 他人占用 / 第三方残留 / 失效清单），越界写入一律中止；双项目（控制面 + 数据面）部署，可选 Workers 数据面                          |
| 平台卸载（loadShed） | 平台在高负载时可能取消部分请求并计入错误，通常在并发优选测速时段出现；排查时先确认当时是否在跑优选 |

### 三、工程与发布

| 约束      | 做法                                                                        |
| ------- | ------------------------------------------------------------------------- |
| 单一版本源   | 根 `package.json` 是唯一版本源，脚本同步到各子包与 CLI 版本文件                                |
| 界面单一来源  | `packages/ui` 是唯一界面源码，构建时注入适配层并 `go:embed` 进桌面版二进制，杜绝两份界面漂移               |
| 跨端一致性   | CLI 与桌面版共用同一份夹具，对同一档案算出**逐位相同**的网段权重与采样策略；改任一端必须两端同时通过                    |
| 静态脱敏    | 构建后从源码反查产物：第三方域名、中文文案、协议关键字不得明文残留                                         |
| 体积预算    | 数据面 ≤ 96 KB、控制面 ≤ 108 KB，构建脚本超限即告警；控制面做字面量级脱敏以守住预算                       |
| 零依赖 CLI | npm 包无第三方运行时依赖，`npx -y` 秒级拉起                                              |
| 内核实现    | 自研一套协议与出站实现，无第三方内核依赖                                                      |
| 发布流程    | `v<版本>` 标签 → npm 暂存（`cfpilot` + `cfpilot-mesh`，需 2FA 批准）；`desktop-v<版本>` 标签 → 全平台产物 + SHA256 清单；`kernel-v*` → 内核独立热更新通道 |

</details>

### 仓库结构

```text
CFPilot/
├── CFPilot-control.zip    # 控制面 Pages 包
├── CFPilot-dataplane.zip  # 数据面 Pages 包
├── data/relay-ips.txt     # 动态保活反代入口清单
└── packages/
    ├── worker-core/       # 边缘内核 + 中文面板
    ├── cli/               # cfpilot —— 部署 + 优选 CLI
    ├── cli-mesh/          # cfpilot-mesh —— 含组网能力的 CLI
    ├── ui/                # 界面源码（单一来源，桌面版与安卓版共用）
    ├── desktop/           # Go 桌面版 / 容器版 / +mesh 组网服务
    ├── android/           # Android 完整管理面板 App
    ├── android-mesh/      # Android 独立 +mesh 组网客户端
    └── edge-relay/        # 盲中继 + 云监测台 Worker 源码
```

> 界面源码独立在 `packages/ui`，构建时内嵌进桌面版与 Android 管理版，保证多端界面一致。

***

## 配置项与环境变量

优先级：**KV(`CONFIG`) > 环境变量 > 内置默认值**。

### 常用环境变量

| 变量                                             | 说明                                                       |
| ---------------------------------------------- | -------------------------------------------------------- |
| `UUID`                                         | VLESS UUID                                               |
| `WS_PATH`                                      | WebSocket 路径（**值要带前导斜杠**；`PATH` 是 Pages 保留名，别用）          |
| `TROJAN_PASSWORD`                              | Trojan 密码                                                |
| `ENABLE_TROJAN` / `ENABLE_XHTTP`               | 入站开关                                                     |
| `DATA_HOST`                                    | 数据面域名（拆分部署时控制面用它生成订阅）                                    |
| `PANEL_PATH` / `PANEL_PASSWORD`                | 面板路径与初始密码（**不是 `ADMIN_PASSWORD`**）                         |
| `PROXYIP`                                      | ProxyIP 池（按直连落地语义解析）                                     |
| `SOCKS5` / `HTTP_PROXY`                        | 落地代理（仅自研数据面）。`https://` 前缀表示代理本身走 TLS，可用 `#sni=域名` 指定握手名 |
| `NAT64`                                        | NAT64 前缀，如 `64:ff9b::`                                   |
| `RELAY_POOL` / `USE_BUILTIN_RELAY`             | 自定义反代入口池 / 内置表开关                                         |
| `RESOLVE_PREFERRED`                            | 出站前自动 DoH 解析优选 IP（默认开）                                   |
| `SUB_VARIANTS`                                 | 下发的节点形态，逗号分隔，默认 `vless-ws,vless-xhttp`                         |
| `OFFICIAL_IP_COUNT` / `PREFERRED_DOMAIN_COUNT` | 内置来源数量（默认 20 / 10）                                       |
| `DLS` / `MAX_LATENCY`                          | 订阅池的最低速度 / 最高延迟阈值                                        |

### 常用 KV 键

| 键                     | 内容                                          |
| --------------------- | ------------------------------------------- |
| `CONFIG`              | 用户配置 JSON（含 uuid / wsPath / trojanPassword） |
| `CFP_DEPLOY_MANIFEST` | 部署清单，**判断 KV 归属的唯一依据**                      |
| `LOCAL_PREFERRED_IPS` | 本地优选结果                                      |
| `SCANNER_TOKEN`       | 扫描回填令牌                                      |

### scanner 常用参数

| 参数                       | 默认       | 说明                                                                                                                                     |
| ------------------------ | -------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `--host`                 | 必填       | 你的域名（作为 SNI / Host）                                                                                                                    |
| `--path`                 | `/vless` | 目标项目的 WS 路径                                                                                                                            |
| `--sample`               | `6556`   | 候选采样数                                                                                                                                  |
| `--top`                  | `15`     | 返回条数                                                                                                                                   |
| `--countries`            | —        | 机房国家筛选，如 `HK,JP,SG`；也接受分组 `ASIA` / `US` 与机房码 `HKG`（自动归一到国家）                                                                            |
| `--token`                | —        | 回填令牌（不填则只输出不回填）                                                                                                                        |
| `--no-verify`            | —        | 只做 101 握手，跳过响应体校验（对接非 CFPilot 项目时用）                                                                                                    |
| `--speed-mode`           | `auto`   | `probe`（走目标探针端点，最忠实）/ `url`（公开测速地址，任何项目可用）/ `auto`                                                                                     |
| `--cidr` / `--ip-file`   | —        | 自定义网段 / 本地 IP 列表                                                                                                                       |
| `cfpilot test --ip <IP>` | —        | 测单个 IP：按 TCP → TLS → WS 101 逐阶段给结论（前一阶段失败即停）；可加 `--speed`（测下行）、`--uuid` / `--trojan-password`（真实隧道校验）、`--json`（脚本处理）、`--path`（非默认探针路径） |

完整参数见 `npx -y cfpilot@latest scan --help` 与 `npx -y cfpilot@latest test --help`。

***

## 配置备份与迁移

面板「出站与高级 → 配置备份与迁移」可以导出/导入配置。

导出是**脱敏**的：不含 UUID、Trojan 口令、入站路径、自定义域名，以及带口令的落地代理；
导出时会明确列出哪些字段没带、为什么。导入前会显示逐项差异，确认后才写入。

换账号、迁移项目、备份都靠它。

***

## 客户端兼容性

| 客户端 / 内核                        | VLESS-WS | Trojan-WS | VLESS-XHTTP | ECH            |
| ------------------------------- | -------- | --------- | ----------- | -------------- |
| Xray-core                       | 支持       | 支持        | 支持（需较新版本）   | 支持（需较新版本）      |
| sing-box                        | 支持       | 支持        | **不支持**     | 支持（1.12+）      |
| mihomo / Clash.Meta             | 支持       | 支持        | 支持（1.19+）   | 支持（`ech-opts`） |
| v2rayN / v2rayNG / Shadowrocket | 支持       | 支持        | 跟随内核       | 跟随内核          |

mihomo 自 1.19+ 原生支持 XHTTP（`network: xhttp` + `xhttp-opts`），实测可稳定连接。
sing-box 暂无该传输类型，订阅生成时不向其下发 XHTTP 节点；老版本 mihomo 会忽略该节点，
不影响其它节点。详见 [客户端兼容性矩阵](docs/COMPATIBILITY.md)。

***

## 免责声明

**本项目仅作学习交流使用**，用于查找资料、学习网络知识，**不鼓励、不支持任何违法行为**。

- 项目中涉及的所有方法与技术均来自互联网公开资料，仅供交流学习；

- 使用者需自行遵守所在地法律法规与 Cloudflare 服务条款（尤其是 Free 套餐的流量与 CPU 限制），并对自身使用行为负全部责任；

- 任何人因使用本项目产生的任何后果（包括但不限于账号封禁、服务中断、法律责任），**本项目及作者概不负责**；

- 如有侵权或不当之处，请联系仓库 issue / PR，将第一时间处理。

***

## License

[AGPL-3.0-only](LICENSE)

本项目采用 **GNU Affero 通用公共许可证 v3.0**：

- 分发或修改本项目代码，须以 AGPL-3.0 开源并注明修改；

- **将修改版部署为网络服务**（含 Cloudflare Pages 等托管形态）向他人提供时，同样须向使用者提供修改后的源码。
