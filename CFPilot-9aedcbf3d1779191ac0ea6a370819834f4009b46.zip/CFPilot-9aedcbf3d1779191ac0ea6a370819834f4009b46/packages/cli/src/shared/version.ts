// 本文件由 scripts/sync-version.mjs 从根 package.json 生成，请勿手改
export const VERSION = '0.60.0-beta.2'
export const NAME = 'cfpilot'
